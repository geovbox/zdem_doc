docsearch({
  apiKey: 'deee6550242977b89b26faae69287043',
  indexName: 'vbox',
  inputSelector: '#rtd-search-form input[type=text]',
  algoliaOptions: {
    hitsPerPage: 6,
  },
  debug: false // Set debug to true if you want to inspect the dropdown
});
